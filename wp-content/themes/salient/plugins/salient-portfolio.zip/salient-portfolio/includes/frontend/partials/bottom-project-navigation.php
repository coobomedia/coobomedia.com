<?php
/**
 * Portfolio single bottom project navigation
 *
 * @package Salient Portfolio
 * @version 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo '<div class="bottom_controls"> <div class="container">';
	nectar_project_single_controls();
echo '</div></div>';
